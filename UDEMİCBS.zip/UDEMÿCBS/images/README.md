<h1> Udemig Academy</h1>

 Udemig Academy, Bootstrap, HTML, CSS ,Js ve responsive tasarım prensipleri kullanılarak geliştirilmiştir.Modern bir eğitim akademisini  nasıl tasarlandığını öğrenmek ve kullanıcıların bir eğitim akademisini keşfetmelerini sağlamak için harika bir fırsattır.

 ![](Udemig.gif)